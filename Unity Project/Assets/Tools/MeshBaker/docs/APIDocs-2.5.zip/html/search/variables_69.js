var searchData=
[
  ['idealheight',['idealHeight',['../class_m_b___texture_combiner_1_1_m_b___tex_set.html#a848384a773a7dbf6f955965f10b428ab',1,'MB_TextureCombiner::MB_TexSet']]],
  ['idealwidth',['idealWidth',['../class_m_b___texture_combiner_1_1_m_b___tex_set.html#a80c63208e16e1a0822deffc48a3b846b',1,'MB_TextureCombiner::MB_TexSet']]]
];
