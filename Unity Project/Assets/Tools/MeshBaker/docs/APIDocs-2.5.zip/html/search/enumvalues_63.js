var searchData=
[
  ['copy_5fuv2_5funchanged',['copy_UV2_unchanged',['../_m_b2___mesh_baker_common_8cs.html#ada582bb4db651a375e265b22384644e8ad6467bb91f2b5b37697f13261bbd3dd6',1,'MB2_MeshBakerCommon.cs']]]
];
