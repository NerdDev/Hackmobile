var searchData=
[
  ['ignore_5fuv2',['ignore_UV2',['../_m_b2___mesh_baker_common_8cs.html#ada582bb4db651a375e265b22384644e8a1cb645e4e8ea47b147319ade082fdbde',1,'MB2_MeshBakerCommon.cs']]]
];
